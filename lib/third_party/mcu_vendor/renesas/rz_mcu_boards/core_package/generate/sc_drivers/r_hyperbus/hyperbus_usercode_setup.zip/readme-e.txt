If you want to set the optimal access settings for HyperFlash/HyperRAM,
please customize this sample code and add it into your application.

These HyperFlash/HyperRAM setting functions must be executed without accessing HyperBus.
For example, place these codes in on-chip large-capacity RAM, not in memory connected to Hyperbus.

See below for details of the these sample code.

https://www.renesas.com/search/keyword-search.html#q=r01an4658
